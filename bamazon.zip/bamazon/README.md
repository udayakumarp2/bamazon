# bamazon
This is my working client facing node.js application

This is what happens when I client purchases a product.
Total inventory is decreased and the user receives a message.
![GitHub Logo](/purchasing.png)
Format: ![Alt Text](url)
----------------------------------------------------------

This is what happens when a client enters a prodcut that doesn't exits. 

![GitHub Logo](/NotWorking.png)
Format: ![Alt Text](url)

-----------------------------------------------------------
This is what happens when the customer quits the application. 

![GitHub Logo](/Quitting.png)
Format: ![Alt Text](url)



