USE bamazon;



INSERT INTO products(itemid,productname, departmentname, price,stockquantity)
VALUES (1, "bmw hoodie", "Clothing/Apparel", 50, 20 ),
(2, "bmw hoodie", "Clothing/Apparel", 50, 20 ),
(3, "mercedes hoodie", "Clothing/Apparel", 50, 20 ),
(4, "audi hoodie", "Clothing/Apparel", 50, 20 ),
(5, "ferrari hoodie", "Clothing/Apparel", 50, 20 ),
(6, "toothbrush", "Healthcare", 6, 1000 ),
(7, "shampoo", "Healthcare", 6, 1000 ),
(8, "milk", "Produce", 3, 40 ),
(9, "gold chain", "Accessories", 2000, 2 ),
(10, "northface backpack", "Clothing/Apparel", 100, 20 ),
(11, "paint", "Home Improvement", 10, 50 ),
(12, "Gucci Mane album", "Music", 10, 40 );